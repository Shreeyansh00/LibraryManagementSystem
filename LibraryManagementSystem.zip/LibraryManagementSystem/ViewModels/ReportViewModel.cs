using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.ViewModels
{
    /// <summary>
    /// ViewModel for report pages with date range filtering
    /// </summary>
    public class ReportViewModel
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string ReportTitle { get; set; } = string.Empty;
        public PaginatedList<BookIssuance> Issuances { get; set; } = null!;
    }
}
