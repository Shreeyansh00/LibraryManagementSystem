using LibraryManagementSystem.Models;
using LibraryManagementSystem.ViewModels;

namespace LibraryManagementSystem.Services.Interfaces
{
    public interface IIssuanceService
    {
        Task<PaginatedList<BookIssuance>> GetIssuancesAsync(string? status, int pageIndex, int pageSize = 10);
        Task<BookIssuance?> GetIssuanceByIdAsync(int id);
        Task<BookIssuance?> GetIssuanceWithDetailsAsync(int id);
        Task<bool> IssueBookAsync(int bookId, int memberId, int issuedByUserId, DateTime issueDate, DateTime dueDate, string? remarks);
        Task<ReturnViewModel?> GetReturnDetailsAsync(int issuanceId);
        Task<bool> ReturnBookAsync(int issuanceId, DateTime returnDate, string? remarks);
        Task<IEnumerable<BookIssuance>> GetOverdueIssuancesAsync();
    }
}
