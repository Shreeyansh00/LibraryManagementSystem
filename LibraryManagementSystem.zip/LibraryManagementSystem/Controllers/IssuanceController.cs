using System.Security.Claims;
using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Handles book issuance and return operations
    /// </summary>
    [Authorize]
    public class IssuanceController : Controller
    {
        private readonly IIssuanceService _issuanceService;
        private readonly IBookService _bookService;
        private readonly IMemberService _memberService;
        private readonly ILogger<IssuanceController> _logger;

        public IssuanceController(
            IIssuanceService issuanceService,
            IBookService bookService,
            IMemberService memberService,
            ILogger<IssuanceController> logger)
        {
            _issuanceService = issuanceService;
            _bookService = bookService;
            _memberService = memberService;
            _logger = logger;
        }

        // GET: Issuance - List all issuances
        public async Task<IActionResult> Index(string? status, int page = 1)
        {
            var issuances = await _issuanceService.GetIssuancesAsync(status, page);
            ViewData["StatusFilter"] = status;
            return View(issuances);
        }

        // GET: Issuance/Issue - Show issue form
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Issue()
        {
            var viewModel = await PopulateIssuanceViewModel(new IssuanceViewModel());
            return View(viewModel);
        }

        // POST: Issuance/Issue - Process book issue
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Issue(IssuanceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                model = await PopulateIssuanceViewModel(model);
                return View(model);
            }

            // Get current user ID from claims
            var userIdClaim = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (!int.TryParse(userIdClaim, out int userId))
            {
                TempData["ErrorMessage"] = "Unable to identify the current user.";
                model = await PopulateIssuanceViewModel(model);
                return View(model);
            }

            var result = await _issuanceService.IssueBookAsync(
                model.BookId, model.MemberId, userId,
                model.IssueDate, model.DueDate, model.Remarks);

            if (!result)
            {
                TempData["ErrorMessage"] = "Failed to issue book. It may not be available.";
                model = await PopulateIssuanceViewModel(model);
                return View(model);
            }

            TempData["SuccessMessage"] = "Book issued successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Issuance/Return/5 - Show return form
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Return(int id)
        {
            var returnDetails = await _issuanceService.GetReturnDetailsAsync(id);
            if (returnDetails == null)
            {
                TempData["ErrorMessage"] = "Issuance not found or already returned.";
                return RedirectToAction(nameof(Index));
            }

            return View(returnDetails);
        }

        // POST: Issuance/Return/5 - Process book return
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Return(int id, ReturnViewModel model)
        {
            var result = await _issuanceService.ReturnBookAsync(id, model.ReturnDate, model.Remarks);
            if (!result)
            {
                TempData["ErrorMessage"] = "Failed to process return.";
                return RedirectToAction(nameof(Index));
            }

            TempData["SuccessMessage"] = "Book returned successfully!";
            return RedirectToAction(nameof(Index));
        }

        // Helper to populate dropdown lists for issue form
        private async Task<IssuanceViewModel> PopulateIssuanceViewModel(IssuanceViewModel model)
        {
            // Get available books
            var books = await _bookService.GetBooksAsync(null, null, "available", null, null, 1, 1000);
            model.Books = books.Select(b => new SelectListItem
            {
                Value = b.Id.ToString(),
                Text = $"{b.Title} (Available: {b.AvailableCopies})"
            }).ToList();

            // Get active members
            var members = await _memberService.GetMembersAsync(null, 1, 1000);
            model.Members = members.Where(m => m.IsActive).Select(m => new SelectListItem
            {
                Value = m.Id.ToString(),
                Text = $"{m.FullName} ({m.MembershipId})"
            }).ToList();

            return model;
        }
    }
}
