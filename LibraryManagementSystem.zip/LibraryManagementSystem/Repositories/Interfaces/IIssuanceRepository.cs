using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories.Interfaces
{
    public interface IIssuanceRepository : IRepository<BookIssuance>
    {
        Task<BookIssuance?> GetIssuanceWithDetailsAsync(int id);
        IQueryable<BookIssuance> GetIssuancesWithDetails();
        Task<IEnumerable<BookIssuance>> GetActiveIssuancesByMemberAsync(int memberId);
        Task<IEnumerable<BookIssuance>> GetOverdueIssuancesAsync();
    }
}
