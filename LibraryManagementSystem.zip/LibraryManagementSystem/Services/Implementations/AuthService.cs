using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using LibraryManagementSystem.Services.Interfaces;

namespace LibraryManagementSystem.Services.Implementations
{
    /// <summary>
    /// Authentication service handling user login
    /// </summary>
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _userRepository;
        private readonly ILogger<AuthService> _logger;

        public AuthService(IUserRepository userRepository, ILogger<AuthService> logger)
        {
            _userRepository = userRepository;
            _logger = logger;
        }

        public async Task<User?> AuthenticateAsync(string email, string password)
        {
            try
            {
                var user = await _userRepository.GetByEmailAsync(email);
                if (user == null || !user.IsActive)
                {
                    _logger.LogWarning("Login attempt failed for email: {Email}", email);
                    return null;
                }

                if (!user.VerifyPassword(password))
                {
                    _logger.LogWarning("Invalid password for email: {Email}", email);
                    return null;
                }

                _logger.LogInformation("User {Email} logged in successfully", email);
                return user;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error during authentication for {Email}", email);
                throw;
            }
        }

        public async Task<User?> GetUserByIdAsync(int id)
        {
            return await _userRepository.GetUserWithRoleAsync(id);
        }
    }
}
