using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    /// <summary>
    /// Abstract base entity providing common Id property (Abstraction + Inheritance)
    /// </summary>
    public abstract class BaseEntity
    {
        [Key]
        public int Id { get; set; }
    }
}
