using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using LibraryManagementSystem.Services.Interfaces;

namespace LibraryManagementSystem.Services.Implementations
{
    public class AuthorService : IAuthorService
    {
        private readonly IAuthorRepository _authorRepository;
        private readonly IBookRepository _bookRepository;
        private readonly ILogger<AuthorService> _logger;

        public AuthorService(IAuthorRepository authorRepository, IBookRepository bookRepository, ILogger<AuthorService> logger)
        {
            _authorRepository = authorRepository;
            _bookRepository = bookRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<Author>> GetAllAuthorsAsync()
        {
            return await _authorRepository.GetAllAsync();
        }

        public async Task<Author?> GetAuthorByIdAsync(int id)
        {
            return await _authorRepository.GetByIdAsync(id);
        }

        public async Task<Author?> GetAuthorWithBooksAsync(int id)
        {
            return await _authorRepository.GetAuthorWithBooksAsync(id);
        }

        public async Task CreateAuthorAsync(Author author)
        {
            await _authorRepository.AddAsync(author);
            await _authorRepository.SaveChangesAsync();
            _logger.LogInformation("Author created: {Name}", author.FullName);
        }

        public async Task UpdateAuthorAsync(Author author)
        {
            _authorRepository.Update(author);
            await _authorRepository.SaveChangesAsync();
            _logger.LogInformation("Author updated: {Name}", author.FullName);
        }

        public async Task DeleteAuthorAsync(int id)
        {
            var author = await _authorRepository.GetByIdAsync(id);
            if (author != null)
            {
                _authorRepository.Delete(author);
                await _authorRepository.SaveChangesAsync();
                _logger.LogInformation("Author deleted: {Name} (Id: {Id})", author.FullName, id);
            }
        }

        public async Task<bool> HasBooksAsync(int authorId)
        {
            return await _bookRepository.ExistsAsync(b => b.AuthorId == authorId);
        }
    }
}
