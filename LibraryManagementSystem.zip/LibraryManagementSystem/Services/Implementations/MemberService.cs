using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;

namespace LibraryManagementSystem.Services.Implementations
{
    public class MemberService : IMemberService
    {
        private readonly IMemberRepository _memberRepository;
        private readonly ILogger<MemberService> _logger;

        public MemberService(IMemberRepository memberRepository, ILogger<MemberService> logger)
        {
            _memberRepository = memberRepository;
            _logger = logger;
        }

        public async Task<PaginatedList<Member>> GetMembersAsync(string? searchTerm, int pageIndex, int pageSize = 10)
        {
            var query = _memberRepository.Query();

            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var term = searchTerm.ToLower();
                query = query.Where(m =>
                    m.FullName.ToLower().Contains(term) ||
                    m.Email.ToLower().Contains(term) ||
                    m.MembershipId.ToLower().Contains(term));
            }

            query = query.OrderByDescending(m => m.CreatedAt);
            return await PaginatedList<Member>.CreateAsync(query, pageIndex, pageSize);
        }

        public async Task<Member?> GetMemberByIdAsync(int id)
        {
            return await _memberRepository.GetByIdAsync(id);
        }

        public async Task<Member?> GetMemberWithIssuancesAsync(int id)
        {
            return await _memberRepository.GetMemberWithIssuancesAsync(id);
        }

        public async Task CreateMemberAsync(Member member)
        {
            await _memberRepository.AddAsync(member);
            await _memberRepository.SaveChangesAsync();
            _logger.LogInformation("Member created: {Name} ({MembershipId})", member.FullName, member.MembershipId);
        }

        public async Task UpdateMemberAsync(Member member)
        {
            _memberRepository.Update(member);
            await _memberRepository.SaveChangesAsync();
            _logger.LogInformation("Member updated: {Name}", member.FullName);
        }

        public async Task DeleteMemberAsync(int id)
        {
            var member = await _memberRepository.GetByIdAsync(id);
            if (member != null)
            {
                _memberRepository.Delete(member);
                await _memberRepository.SaveChangesAsync();
                _logger.LogInformation("Member deleted: {Name} (Id: {Id})", member.FullName, id);
            }
        }

        public async Task<bool> MembershipIdExistsAsync(string membershipId, int? excludeId = null)
        {
            if (excludeId.HasValue)
                return await _memberRepository.ExistsAsync(m => m.MembershipId == membershipId && m.Id != excludeId.Value);
            return await _memberRepository.ExistsAsync(m => m.MembershipId == membershipId);
        }
    }
}
