using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Member/Student CRUD controller with search and pagination
    /// </summary>
    [Authorize]
    public class MemberController : Controller
    {
        private readonly IMemberService _memberService;
        private readonly ILogger<MemberController> _logger;

        public MemberController(IMemberService memberService, ILogger<MemberController> logger)
        {
            _memberService = memberService;
            _logger = logger;
        }

        public async Task<IActionResult> Index(string? searchTerm, int page = 1)
        {
            var members = await _memberService.GetMembersAsync(searchTerm, page);
            ViewData["SearchTerm"] = searchTerm;
            return View(members);
        }

        public async Task<IActionResult> Details(int id)
        {
            var member = await _memberService.GetMemberWithIssuancesAsync(id);
            if (member == null)
                return NotFound();

            return View(member);
        }

        [Authorize(Roles = "Admin,Librarian")]
        public IActionResult Create()
        {
            return View(new MemberViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Create(MemberViewModel model)
        {
            if (await _memberService.MembershipIdExistsAsync(model.MembershipId))
            {
                ModelState.AddModelError("MembershipId", "This Membership ID already exists.");
            }

            if (!ModelState.IsValid)
                return View(model);

            var member = new Member
            {
                FullName = model.FullName,
                Email = model.Email,
                Phone = model.Phone,
                MembershipId = model.MembershipId,
                MemberType = model.MemberType,
                IsActive = model.IsActive
            };

            await _memberService.CreateMemberAsync(member);
            TempData["SuccessMessage"] = "Member created successfully!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Edit(int id)
        {
            var member = await _memberService.GetMemberByIdAsync(id);
            if (member == null)
                return NotFound();

            var model = new MemberViewModel
            {
                Id = member.Id,
                FullName = member.FullName,
                Email = member.Email,
                Phone = member.Phone,
                MembershipId = member.MembershipId,
                MemberType = member.MemberType,
                IsActive = member.IsActive
            };

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Edit(int id, MemberViewModel model)
        {
            if (id != model.Id)
                return NotFound();

            if (await _memberService.MembershipIdExistsAsync(model.MembershipId, model.Id))
            {
                ModelState.AddModelError("MembershipId", "This Membership ID already exists.");
            }

            if (!ModelState.IsValid)
                return View(model);

            var member = await _memberService.GetMemberByIdAsync(id);
            if (member == null)
                return NotFound();

            member.FullName = model.FullName;
            member.Email = model.Email;
            member.Phone = model.Phone;
            member.MembershipId = model.MembershipId;
            member.MemberType = model.MemberType;
            member.IsActive = model.IsActive;

            await _memberService.UpdateMemberAsync(member);
            TempData["SuccessMessage"] = "Member updated successfully!";
            return RedirectToAction(nameof(Index));
        }

        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var member = await _memberService.GetMemberByIdAsync(id);
            if (member == null)
                return NotFound();

            return View(member);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                await _memberService.DeleteMemberAsync(id);
                TempData["SuccessMessage"] = "Member deleted successfully!";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting member {MemberId}", id);
                TempData["ErrorMessage"] = "Cannot delete this member. They may have active issuances.";
            }
            return RedirectToAction(nameof(Index));
        }
    }
}
