using LibraryManagementSystem.Models;
using LibraryManagementSystem.ViewModels;

namespace LibraryManagementSystem.Services.Interfaces
{
    public interface IMemberService
    {
        Task<PaginatedList<Member>> GetMembersAsync(string? searchTerm, int pageIndex, int pageSize = 10);
        Task<Member?> GetMemberByIdAsync(int id);
        Task<Member?> GetMemberWithIssuancesAsync(int id);
        Task CreateMemberAsync(Member member);
        Task UpdateMemberAsync(Member member);
        Task DeleteMemberAsync(int id);
        Task<bool> MembershipIdExistsAsync(string membershipId, int? excludeId = null);
    }
}
