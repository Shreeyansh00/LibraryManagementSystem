using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.ViewModels
{
    public class MemberViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, MinimumLength = 2)]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [StringLength(100)]
        [EmailAddress(ErrorMessage = "Invalid email")]
        public string Email { get; set; } = string.Empty;

        [StringLength(15)]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "Membership ID is required")]
        [StringLength(20)]
        [Display(Name = "Membership ID")]
        public string MembershipId { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Member Type")]
        public string MemberType { get; set; } = "Student";

        public bool IsActive { get; set; } = true;
    }
}
