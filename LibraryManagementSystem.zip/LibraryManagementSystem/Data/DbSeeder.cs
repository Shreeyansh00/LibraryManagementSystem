using LibraryManagementSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Data
{
    /// <summary>
    /// Seeds the database with initial data for testing.
    /// Called during application startup.
    /// </summary>
    public static class DbSeeder
    {
        public static async Task SeedAsync(ApplicationDbContext context)
        {
            // Ensure database is created
            await context.Database.EnsureCreatedAsync();

            // Only seed if database is empty
            if (await context.Roles.AnyAsync())
                return;

            // Seed Roles
            var adminRole = new Role { Name = "Admin" };
            var librarianRole = new Role { Name = "Librarian" };
            context.Roles.AddRange(adminRole, librarianRole);
            await context.SaveChangesAsync();

            // Seed Users (password: Password@123)
            var admin = new User
            {
                FullName = "System Administrator",
                Email = "admin@library.com",
                RoleId = adminRole.Id,
                IsActive = true
            };
            admin.SetPassword("Password@123");

            var librarian = new User
            {
                FullName = "Jane Librarian",
                Email = "librarian@library.com",
                RoleId = librarianRole.Id,
                IsActive = true
            };
            librarian.SetPassword("Password@123");

            context.Users.AddRange(admin, librarian);
            await context.SaveChangesAsync();

            // Seed Authors
            var authors = new List<Author>
            {
                new Author { FullName = "George Orwell", Biography = "English novelist and essayist, known for 1984 and Animal Farm." },
                new Author { FullName = "J.K. Rowling", Biography = "British author best known for the Harry Potter series." },
                new Author { FullName = "Stephen Hawking", Biography = "English theoretical physicist and cosmologist." },
                new Author { FullName = "Robert C. Martin", Biography = "American software engineer and author of Clean Code." },
                new Author { FullName = "Yuval Noah Harari", Biography = "Israeli historian and author of Sapiens." }
            };
            context.Authors.AddRange(authors);
            await context.SaveChangesAsync();

            // Seed Categories
            var categories = new List<Category>
            {
                new Category { Name = "Fiction", Description = "Novels, short stories, and literary fiction" },
                new Category { Name = "Science", Description = "Physics, chemistry, biology and natural sciences" },
                new Category { Name = "History", Description = "World history, civilizations, and historical events" },
                new Category { Name = "Technology", Description = "Computer science, software engineering, and IT" },
                new Category { Name = "Literature", Description = "Classic and contemporary literary works" }
            };
            context.Categories.AddRange(categories);
            await context.SaveChangesAsync();

            // Seed Books
            var books = new List<Book>
            {
                new Book { Title = "1984", ISBN = "978-0451524935", AuthorId = authors[0].Id, CategoryId = categories[0].Id, Publisher = "Signet Classics", PublicationYear = 1949, TotalCopies = 5, AvailableCopies = 5, Description = "A dystopian novel set in a totalitarian society." },
                new Book { Title = "Animal Farm", ISBN = "978-0451526342", AuthorId = authors[0].Id, CategoryId = categories[0].Id, Publisher = "Signet Classics", PublicationYear = 1945, TotalCopies = 3, AvailableCopies = 3, Description = "An allegorical novella about a group of farm animals." },
                new Book { Title = "Harry Potter and the Philosopher's Stone", ISBN = "978-0747532699", AuthorId = authors[1].Id, CategoryId = categories[0].Id, Publisher = "Bloomsbury", PublicationYear = 1997, TotalCopies = 7, AvailableCopies = 7, Description = "The first book in the Harry Potter series." },
                new Book { Title = "Harry Potter and the Chamber of Secrets", ISBN = "978-0747538486", AuthorId = authors[1].Id, CategoryId = categories[0].Id, Publisher = "Bloomsbury", PublicationYear = 1998, TotalCopies = 5, AvailableCopies = 5, Description = "The second book in the Harry Potter series." },
                new Book { Title = "A Brief History of Time", ISBN = "978-0553380163", AuthorId = authors[2].Id, CategoryId = categories[1].Id, Publisher = "Bantam", PublicationYear = 1988, TotalCopies = 4, AvailableCopies = 4, Description = "A popular-science book on cosmology." },
                new Book { Title = "The Universe in a Nutshell", ISBN = "978-0553802023", AuthorId = authors[2].Id, CategoryId = categories[1].Id, Publisher = "Bantam", PublicationYear = 2001, TotalCopies = 3, AvailableCopies = 3, Description = "A sequel to A Brief History of Time." },
                new Book { Title = "Clean Code", ISBN = "978-0132350884", AuthorId = authors[3].Id, CategoryId = categories[3].Id, Publisher = "Prentice Hall", PublicationYear = 2008, TotalCopies = 6, AvailableCopies = 6, Description = "A handbook of agile software craftsmanship." },
                new Book { Title = "The Clean Coder", ISBN = "978-0137081073", AuthorId = authors[3].Id, CategoryId = categories[3].Id, Publisher = "Prentice Hall", PublicationYear = 2011, TotalCopies = 4, AvailableCopies = 4, Description = "A code of conduct for professional programmers." },
                new Book { Title = "Sapiens: A Brief History of Humankind", ISBN = "978-0062316097", AuthorId = authors[4].Id, CategoryId = categories[2].Id, Publisher = "Harper", PublicationYear = 2015, TotalCopies = 5, AvailableCopies = 5, Description = "A narrative of humanity's creation and evolution." },
                new Book { Title = "Homo Deus: A Brief History of Tomorrow", ISBN = "978-0062464316", AuthorId = authors[4].Id, CategoryId = categories[2].Id, Publisher = "Harper", PublicationYear = 2017, TotalCopies = 3, AvailableCopies = 3, Description = "An exploration of humanity's future." }
            };
            context.Books.AddRange(books);
            await context.SaveChangesAsync();

            // Seed Members
            var members = new List<Member>
            {
                new Member { FullName = "Alice Johnson", Email = "alice@university.edu", Phone = "9876543210", MembershipId = "MEM-001", MemberType = "Student", JoinDate = DateTime.UtcNow.AddMonths(-6) },
                new Member { FullName = "Bob Smith", Email = "bob@university.edu", Phone = "9876543211", MembershipId = "MEM-002", MemberType = "Student", JoinDate = DateTime.UtcNow.AddMonths(-4) },
                new Member { FullName = "Dr. Carol Williams", Email = "carol@university.edu", Phone = "9876543212", MembershipId = "MEM-003", MemberType = "Faculty", JoinDate = DateTime.UtcNow.AddYears(-2) },
                new Member { FullName = "David Brown", Email = "david@university.edu", Phone = "9876543213", MembershipId = "MEM-004", MemberType = "Student", JoinDate = DateTime.UtcNow.AddMonths(-1) },
                new Member { FullName = "Eva Martinez", Email = "eva@university.edu", Phone = "9876543214", MembershipId = "MEM-005", MemberType = "Staff", JoinDate = DateTime.UtcNow.AddYears(-1) }
            };
            context.Members.AddRange(members);
            await context.SaveChangesAsync();
        }
    }
}
