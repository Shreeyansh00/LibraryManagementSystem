using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    /// <summary>
    /// Member/Student entity
    /// </summary>
    public class Member : AuditableEntity
    {
        [Required(ErrorMessage = "Name is required")]
        [StringLength(100, MinimumLength = 2)]
        [Display(Name = "Full Name")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email is required")]
        [StringLength(100)]
        [EmailAddress(ErrorMessage = "Invalid email address")]
        public string Email { get; set; } = string.Empty;

        [StringLength(15)]
        [Phone(ErrorMessage = "Invalid phone number")]
        public string? Phone { get; set; }

        [Required(ErrorMessage = "Membership ID is required")]
        [StringLength(20)]
        [Display(Name = "Membership ID")]
        public string MembershipId { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        [Display(Name = "Member Type")]
        public string MemberType { get; set; } = "Student"; // Student, Faculty, Staff

        [Display(Name = "Join Date")]
        [DataType(DataType.Date)]
        public DateTime JoinDate { get; set; } = DateTime.UtcNow;

        public bool IsActive { get; set; } = true;

        // Navigation property
        public virtual ICollection<BookIssuance> Issuances { get; set; } = new List<BookIssuance>();
    }
}
