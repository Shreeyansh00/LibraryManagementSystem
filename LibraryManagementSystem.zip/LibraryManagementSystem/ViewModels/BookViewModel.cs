using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LibraryManagementSystem.ViewModels
{
    /// <summary>
    /// ViewModel for Book Create/Edit forms (does not expose entity directly)
    /// </summary>
    public class BookViewModel
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Title is required")]
        [StringLength(200, MinimumLength = 1)]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "ISBN is required")]
        [StringLength(20)]
        [Display(Name = "ISBN")]
        public string ISBN { get; set; } = string.Empty;

        [Required(ErrorMessage = "Author is required")]
        [Display(Name = "Author")]
        public int AuthorId { get; set; }

        [Required(ErrorMessage = "Category is required")]
        [Display(Name = "Category")]
        public int CategoryId { get; set; }

        [StringLength(100)]
        public string? Publisher { get; set; }

        [Display(Name = "Publication Year")]
        [Range(1000, 2100, ErrorMessage = "Enter a valid year")]
        public int? PublicationYear { get; set; }

        [Required]
        [Range(1, 10000, ErrorMessage = "Must be at least 1")]
        [Display(Name = "Total Copies")]
        public int TotalCopies { get; set; } = 1;

        [StringLength(1000)]
        public string? Description { get; set; }

        // Dropdown lists for the form
        public List<SelectListItem> Authors { get; set; } = new();
        public List<SelectListItem> Categories { get; set; } = new();
    }
}
