using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;

namespace LibraryManagementSystem.Services.Implementations
{
    /// <summary>
    /// Handles book issuance and return operations with fine calculation
    /// </summary>
    public class IssuanceService : IIssuanceService
    {
        private readonly IIssuanceRepository _issuanceRepository;
        private readonly IBookRepository _bookRepository;
        private readonly ILogger<IssuanceService> _logger;

        public IssuanceService(
            IIssuanceRepository issuanceRepository,
            IBookRepository bookRepository,
            ILogger<IssuanceService> logger)
        {
            _issuanceRepository = issuanceRepository;
            _bookRepository = bookRepository;
            _logger = logger;
        }

        public async Task<PaginatedList<BookIssuance>> GetIssuancesAsync(
            string? status, int pageIndex, int pageSize = 10)
        {
            var query = _issuanceRepository.GetIssuancesWithDetails();

            if (!string.IsNullOrWhiteSpace(status))
            {
                query = query.Where(i => i.Status == status);
            }

            query = query.OrderByDescending(i => i.IssueDate);
            return await PaginatedList<BookIssuance>.CreateAsync(query, pageIndex, pageSize);
        }

        public async Task<BookIssuance?> GetIssuanceByIdAsync(int id)
        {
            return await _issuanceRepository.GetByIdAsync(id);
        }

        public async Task<BookIssuance?> GetIssuanceWithDetailsAsync(int id)
        {
            return await _issuanceRepository.GetIssuanceWithDetailsAsync(id);
        }

        public async Task<bool> IssueBookAsync(
            int bookId, int memberId, int issuedByUserId,
            DateTime issueDate, DateTime dueDate, string? remarks)
        {
            var book = await _bookRepository.GetByIdAsync(bookId);
            if (book == null || !book.TryIssue())
            {
                _logger.LogWarning("Failed to issue book {BookId}: not available", bookId);
                return false;
            }

            var issuance = new BookIssuance
            {
                BookId = bookId,
                MemberId = memberId,
                IssuedByUserId = issuedByUserId,
                IssueDate = issueDate,
                DueDate = dueDate,
                Status = "Issued",
                Remarks = remarks
            };

            _bookRepository.Update(book);
            await _issuanceRepository.AddAsync(issuance);
            await _issuanceRepository.SaveChangesAsync();

            _logger.LogInformation("Book {BookId} issued to member {MemberId}", bookId, memberId);
            return true;
        }

        public async Task<ReturnViewModel?> GetReturnDetailsAsync(int issuanceId)
        {
            var issuance = await _issuanceRepository.GetIssuanceWithDetailsAsync(issuanceId);
            if (issuance == null || issuance.Status != "Issued")
                return null;

            var returnDate = DateTime.UtcNow;
            var overdueDays = Math.Max(0, (returnDate.Date - issuance.DueDate.Date).Days);
            var fine = overdueDays * 1.0m; // Rs 1 per day

            return new ReturnViewModel
            {
                IssuanceId = issuance.Id,
                BookTitle = issuance.Book?.Title ?? "Unknown",
                MemberName = issuance.Member?.FullName ?? "Unknown",
                IssueDate = issuance.IssueDate,
                DueDate = issuance.DueDate,
                ReturnDate = returnDate,
                OverdueDays = overdueDays,
                FineAmount = fine
            };
        }

        public async Task<bool> ReturnBookAsync(int issuanceId, DateTime returnDate, string? remarks)
        {
            var issuance = await _issuanceRepository.GetIssuanceWithDetailsAsync(issuanceId);
            if (issuance == null || issuance.Status != "Issued")
                return false;

            // Update the issuance record
            issuance.ReturnDate = returnDate;
            issuance.Status = "Returned";
            issuance.Remarks = remarks;
            issuance.CalculateFine(); // Calculate fine based on overdue days

            // Return the book copy
            var book = await _bookRepository.GetByIdAsync(issuance.BookId);
            if (book != null)
            {
                book.ReturnCopy();
                _bookRepository.Update(book);
            }

            _issuanceRepository.Update(issuance);
            await _issuanceRepository.SaveChangesAsync();

            _logger.LogInformation("Book {BookId} returned by member {MemberId}. Fine: {Fine}",
                issuance.BookId, issuance.MemberId, issuance.FineAmount);
            return true;
        }

        public async Task<IEnumerable<BookIssuance>> GetOverdueIssuancesAsync()
        {
            return await _issuanceRepository.GetOverdueIssuancesAsync();
        }
    }
}
