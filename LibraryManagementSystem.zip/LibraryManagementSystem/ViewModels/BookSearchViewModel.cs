using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LibraryManagementSystem.ViewModels
{
    /// <summary>
    /// ViewModel for book listing with search, filter, sort, and pagination
    /// </summary>
    public class BookSearchViewModel
    {
        public PaginatedList<Book> Books { get; set; } = null!;
        public string? SearchTerm { get; set; }
        public int? CategoryFilter { get; set; }
        public string? AvailabilityFilter { get; set; } // "available", "unavailable", or null for all
        public string? SortBy { get; set; }
        public string? SortOrder { get; set; }
        public List<SelectListItem> Categories { get; set; } = new();
    }
}
