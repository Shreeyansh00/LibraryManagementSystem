using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;

namespace LibraryManagementSystem.Services.Implementations
{
    public class BookService : IBookService
    {
        private readonly IBookRepository _bookRepository;
        private readonly ILogger<BookService> _logger;

        public BookService(IBookRepository bookRepository, ILogger<BookService> logger)
        {
            _bookRepository = bookRepository;
            _logger = logger;
        }

        public async Task<PaginatedList<Book>> GetBooksAsync(
            string? searchTerm, int? categoryId, string? availability,
            string? sortBy, string? sortOrder, int pageIndex, int pageSize = 10)
        {
            var query = _bookRepository.GetBooksWithDetails();

            // Search filter
            if (!string.IsNullOrWhiteSpace(searchTerm))
            {
                var term = searchTerm.ToLower();
                query = query.Where(b =>
                    b.Title.ToLower().Contains(term) ||
                    b.ISBN.ToLower().Contains(term) ||
                    b.Author!.FullName.ToLower().Contains(term));
            }

            // Category filter
            if (categoryId.HasValue && categoryId > 0)
            {
                query = query.Where(b => b.CategoryId == categoryId.Value);
            }

            // Availability filter
            if (!string.IsNullOrWhiteSpace(availability))
            {
                query = availability.ToLower() switch
                {
                    "available" => query.Where(b => b.AvailableCopies > 0),
                    "unavailable" => query.Where(b => b.AvailableCopies == 0),
                    _ => query
                };
            }

            // Sorting
            query = sortBy?.ToLower() switch
            {
                "title" => sortOrder == "desc" ? query.OrderByDescending(b => b.Title) : query.OrderBy(b => b.Title),
                "author" => sortOrder == "desc" ? query.OrderByDescending(b => b.Author!.FullName) : query.OrderBy(b => b.Author!.FullName),
                "year" => sortOrder == "desc" ? query.OrderByDescending(b => b.PublicationYear) : query.OrderBy(b => b.PublicationYear),
                "available" => sortOrder == "desc" ? query.OrderByDescending(b => b.AvailableCopies) : query.OrderBy(b => b.AvailableCopies),
                _ => query.OrderByDescending(b => b.CreatedAt)
            };

            return await PaginatedList<Book>.CreateAsync(query, pageIndex, pageSize);
        }

        public async Task<Book?> GetBookByIdAsync(int id)
        {
            return await _bookRepository.GetByIdAsync(id);
        }

        public async Task<Book?> GetBookWithDetailsAsync(int id)
        {
            return await _bookRepository.GetBookWithDetailsAsync(id);
        }

        public async Task CreateBookAsync(Book book)
        {
            book.AvailableCopies = book.TotalCopies;
            await _bookRepository.AddAsync(book);
            await _bookRepository.SaveChangesAsync();
            _logger.LogInformation("Book created: {Title} (ISBN: {ISBN})", book.Title, book.ISBN);
        }

        public async Task UpdateBookAsync(Book book)
        {
            _bookRepository.Update(book);
            await _bookRepository.SaveChangesAsync();
            _logger.LogInformation("Book updated: {Title} (Id: {Id})", book.Title, book.Id);
        }

        public async Task DeleteBookAsync(int id)
        {
            var book = await _bookRepository.GetByIdAsync(id);
            if (book != null)
            {
                _bookRepository.Delete(book);
                await _bookRepository.SaveChangesAsync();
                _logger.LogInformation("Book deleted: {Title} (Id: {Id})", book.Title, id);
            }
        }

        public async Task<bool> IsbnExistsAsync(string isbn, int? excludeId = null)
        {
            if (excludeId.HasValue)
                return await _bookRepository.ExistsAsync(b => b.ISBN == isbn && b.Id != excludeId.Value);
            return await _bookRepository.ExistsAsync(b => b.ISBN == isbn);
        }
    }
}
