using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models
{
    /// <summary>
    /// Book issuance/return record with fine calculation (Encapsulation + Polymorphism)
    /// </summary>
    public class BookIssuance : BaseEntity
    {
        [Required]
        [Display(Name = "Book")]
        public int BookId { get; set; }

        [Required]
        [Display(Name = "Member")]
        public int MemberId { get; set; }

        [Required]
        [Display(Name = "Issued By")]
        public int IssuedByUserId { get; set; }

        [Required]
        [Display(Name = "Issue Date")]
        [DataType(DataType.Date)]
        public DateTime IssueDate { get; set; } = DateTime.UtcNow;

        [Required]
        [Display(Name = "Due Date")]
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; }

        [Display(Name = "Return Date")]
        [DataType(DataType.Date)]
        public DateTime? ReturnDate { get; set; }

        [Display(Name = "Fine Amount")]
        public decimal FineAmount { get; set; } = 0;

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Issued"; // Issued, Returned, Overdue

        [StringLength(500)]
        public string? Remarks { get; set; }

        // Navigation properties
        [ForeignKey("BookId")]
        public virtual Book? Book { get; set; }

        [ForeignKey("MemberId")]
        public virtual Member? Member { get; set; }

        [ForeignKey("IssuedByUserId")]
        public virtual User? IssuedByUser { get; set; }

        // Encapsulation: computed properties
        [NotMapped]
        public bool IsOverdue => Status == "Issued" && DateTime.UtcNow.Date > DueDate.Date;

        [NotMapped]
        public int OverdueDays
        {
            get
            {
                if (Status == "Returned" && ReturnDate.HasValue)
                    return Math.Max(0, (ReturnDate.Value.Date - DueDate.Date).Days);
                if (Status == "Issued")
                    return Math.Max(0, (DateTime.UtcNow.Date - DueDate.Date).Days);
                return 0;
            }
        }

        /// <summary>
        /// Calculate fine at Rs 1 per overdue day
        /// </summary>
        public decimal CalculateFine(decimal ratePerDay = 1.0m)
        {
            FineAmount = OverdueDays * ratePerDay;
            return FineAmount;
        }
    }
}
