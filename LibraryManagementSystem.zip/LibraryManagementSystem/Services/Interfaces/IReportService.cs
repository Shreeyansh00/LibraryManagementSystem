using LibraryManagementSystem.Models;
using LibraryManagementSystem.ViewModels;

namespace LibraryManagementSystem.Services.Interfaces
{
    public interface IReportService
    {
        Task<PaginatedList<BookIssuance>> GetIssuedBooksReportAsync(DateTime? fromDate, DateTime? toDate, int pageIndex, int pageSize = 15);
        Task<PaginatedList<BookIssuance>> GetReturnedBooksReportAsync(DateTime? fromDate, DateTime? toDate, int pageIndex, int pageSize = 15);
        Task<PaginatedList<BookIssuance>> GetOverdueBooksReportAsync(int pageIndex, int pageSize = 15);
        Task<DashboardViewModel> GetDashboardDataAsync();
    }
}
