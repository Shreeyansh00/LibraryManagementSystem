using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories.Interfaces
{
    /// <summary>
    /// Book-specific repository with search and filter capabilities
    /// </summary>
    public interface IBookRepository : IRepository<Book>
    {
        Task<Book?> GetBookWithDetailsAsync(int id);
        IQueryable<Book> GetBooksWithDetails();
        Task<Book?> GetByIsbnAsync(string isbn);
    }
}
