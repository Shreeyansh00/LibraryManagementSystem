using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.Repositories.Interfaces
{
    public interface IMemberRepository : IRepository<Member>
    {
        Task<Member?> GetMemberWithIssuancesAsync(int id);
        Task<Member?> GetByMembershipIdAsync(string membershipId);
    }
}
