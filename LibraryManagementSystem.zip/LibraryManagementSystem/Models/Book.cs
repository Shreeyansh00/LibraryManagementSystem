using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace LibraryManagementSystem.Models
{
    /// <summary>
    /// Book entity with availability tracking (Encapsulation via computed properties)
    /// </summary>
    public class Book : AuditableEntity
    {
        [Required(ErrorMessage = "Title is required")]
        [StringLength(200, MinimumLength = 1)]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "ISBN is required")]
        [StringLength(20)]
        [Display(Name = "ISBN")]
        public string ISBN { get; set; } = string.Empty;

        [Required]
        [Display(Name = "Author")]
        public int AuthorId { get; set; }

        [Required]
        [Display(Name = "Category")]
        public int CategoryId { get; set; }

        [StringLength(100)]
        public string? Publisher { get; set; }

        [Display(Name = "Publication Year")]
        [Range(1000, 2100, ErrorMessage = "Enter a valid year")]
        public int? PublicationYear { get; set; }

        [Required]
        [Range(1, 10000, ErrorMessage = "Total copies must be at least 1")]
        [Display(Name = "Total Copies")]
        public int TotalCopies { get; set; } = 1;

        [Required]
        [Range(0, 10000)]
        [Display(Name = "Available Copies")]
        public int AvailableCopies { get; set; } = 1;

        [StringLength(1000)]
        public string? Description { get; set; }

        // Navigation properties
        [ForeignKey("AuthorId")]
        public virtual Author? Author { get; set; }

        [ForeignKey("CategoryId")]
        public virtual Category? Category { get; set; }

        public virtual ICollection<BookIssuance> Issuances { get; set; } = new List<BookIssuance>();

        // Encapsulation: computed property for availability check
        [NotMapped]
        public bool IsAvailable => AvailableCopies > 0;

        // Encapsulation: business logic for issuing and returning
        public bool TryIssue()
        {
            if (AvailableCopies <= 0) return false;
            AvailableCopies--;
            return true;
        }

        public void ReturnCopy()
        {
            if (AvailableCopies < TotalCopies)
                AvailableCopies++;
        }
    }
}
