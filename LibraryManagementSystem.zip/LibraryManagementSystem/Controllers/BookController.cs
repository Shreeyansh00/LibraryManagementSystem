using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Book CRUD controller with search, filter, and pagination
    /// </summary>
    [Authorize]
    public class BookController : Controller
    {
        private readonly IBookService _bookService;
        private readonly IAuthorService _authorService;
        private readonly ICategoryService _categoryService;
        private readonly ILogger<BookController> _logger;

        public BookController(
            IBookService bookService,
            IAuthorService authorService,
            ICategoryService categoryService,
            ILogger<BookController> logger)
        {
            _bookService = bookService;
            _authorService = authorService;
            _categoryService = categoryService;
            _logger = logger;
        }

        // GET: Book
        public async Task<IActionResult> Index(
            string? searchTerm, int? categoryFilter, string? availabilityFilter,
            string? sortBy, string? sortOrder, int page = 1)
        {
            var books = await _bookService.GetBooksAsync(
                searchTerm, categoryFilter, availabilityFilter,
                sortBy, sortOrder, page);

            var categories = await _categoryService.GetAllCategoriesAsync();

            var viewModel = new BookSearchViewModel
            {
                Books = books,
                SearchTerm = searchTerm,
                CategoryFilter = categoryFilter,
                AvailabilityFilter = availabilityFilter,
                SortBy = sortBy,
                SortOrder = sortOrder,
                Categories = categories.Select(c => new SelectListItem
                {
                    Value = c.Id.ToString(),
                    Text = c.Name
                }).ToList()
            };

            return View(viewModel);
        }

        // GET: Book/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var book = await _bookService.GetBookWithDetailsAsync(id);
            if (book == null)
                return NotFound();

            return View(book);
        }

        // GET: Book/Create
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Create()
        {
            var viewModel = await PopulateBookViewModel(new BookViewModel());
            return View(viewModel);
        }

        // POST: Book/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Create(BookViewModel model)
        {
            if (await _bookService.IsbnExistsAsync(model.ISBN))
            {
                ModelState.AddModelError("ISBN", "A book with this ISBN already exists.");
            }

            if (!ModelState.IsValid)
            {
                model = await PopulateBookViewModel(model);
                return View(model);
            }

            var book = new Book
            {
                Title = model.Title,
                ISBN = model.ISBN,
                AuthorId = model.AuthorId,
                CategoryId = model.CategoryId,
                Publisher = model.Publisher,
                PublicationYear = model.PublicationYear,
                TotalCopies = model.TotalCopies,
                Description = model.Description
            };

            await _bookService.CreateBookAsync(book);
            TempData["SuccessMessage"] = "Book created successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Book/Edit/5
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Edit(int id)
        {
            var book = await _bookService.GetBookByIdAsync(id);
            if (book == null)
                return NotFound();

            var viewModel = new BookViewModel
            {
                Id = book.Id,
                Title = book.Title,
                ISBN = book.ISBN,
                AuthorId = book.AuthorId,
                CategoryId = book.CategoryId,
                Publisher = book.Publisher,
                PublicationYear = book.PublicationYear,
                TotalCopies = book.TotalCopies,
                Description = book.Description
            };

            viewModel = await PopulateBookViewModel(viewModel);
            return View(viewModel);
        }

        // POST: Book/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Edit(int id, BookViewModel model)
        {
            if (id != model.Id)
                return NotFound();

            if (await _bookService.IsbnExistsAsync(model.ISBN, model.Id))
            {
                ModelState.AddModelError("ISBN", "A book with this ISBN already exists.");
            }

            if (!ModelState.IsValid)
            {
                model = await PopulateBookViewModel(model);
                return View(model);
            }

            var book = await _bookService.GetBookByIdAsync(id);
            if (book == null)
                return NotFound();

            // Calculate available copies adjustment
            var copiesDiff = model.TotalCopies - book.TotalCopies;
            book.Title = model.Title;
            book.ISBN = model.ISBN;
            book.AuthorId = model.AuthorId;
            book.CategoryId = model.CategoryId;
            book.Publisher = model.Publisher;
            book.PublicationYear = model.PublicationYear;
            book.TotalCopies = model.TotalCopies;
            book.AvailableCopies = Math.Max(0, book.AvailableCopies + copiesDiff);
            book.Description = model.Description;

            await _bookService.UpdateBookAsync(book);
            TempData["SuccessMessage"] = "Book updated successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Book/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var book = await _bookService.GetBookWithDetailsAsync(id);
            if (book == null)
                return NotFound();

            return View(book);
        }

        // POST: Book/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                await _bookService.DeleteBookAsync(id);
                TempData["SuccessMessage"] = "Book deleted successfully!";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error deleting book {BookId}", id);
                TempData["ErrorMessage"] = "Cannot delete this book. It may have active issuances.";
            }
            return RedirectToAction(nameof(Index));
        }

        // Helper to populate dropdown lists
        private async Task<BookViewModel> PopulateBookViewModel(BookViewModel model)
        {
            var authors = await _authorService.GetAllAuthorsAsync();
            var categories = await _categoryService.GetAllCategoriesAsync();

            model.Authors = authors.Select(a => new SelectListItem
            {
                Value = a.Id.ToString(),
                Text = a.FullName
            }).ToList();

            model.Categories = categories.Select(c => new SelectListItem
            {
                Value = c.Id.ToString(),
                Text = c.Name
            }).ToList();

            return model;
        }
    }
}
