using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Reports controller for issued, returned, and overdue books
    /// </summary>
    [Authorize]
    public class ReportController : Controller
    {
        private readonly IReportService _reportService;

        public ReportController(IReportService reportService)
        {
            _reportService = reportService;
        }

        // GET: Report/IssuedBooks
        public async Task<IActionResult> IssuedBooks(DateTime? fromDate, DateTime? toDate, int page = 1)
        {
            var issuances = await _reportService.GetIssuedBooksReportAsync(fromDate, toDate, page);
            var viewModel = new ReportViewModel
            {
                FromDate = fromDate,
                ToDate = toDate,
                ReportTitle = "Issued Books Report",
                Issuances = issuances
            };
            return View(viewModel);
        }

        // GET: Report/ReturnedBooks
        public async Task<IActionResult> ReturnedBooks(DateTime? fromDate, DateTime? toDate, int page = 1)
        {
            var issuances = await _reportService.GetReturnedBooksReportAsync(fromDate, toDate, page);
            var viewModel = new ReportViewModel
            {
                FromDate = fromDate,
                ToDate = toDate,
                ReportTitle = "Returned Books Report",
                Issuances = issuances
            };
            return View(viewModel);
        }

        // GET: Report/OverdueBooks
        public async Task<IActionResult> OverdueBooks(int page = 1)
        {
            var issuances = await _reportService.GetOverdueBooksReportAsync(page);
            var viewModel = new ReportViewModel
            {
                ReportTitle = "Overdue Books Report",
                Issuances = issuances
            };
            return View(viewModel);
        }
    }
}
