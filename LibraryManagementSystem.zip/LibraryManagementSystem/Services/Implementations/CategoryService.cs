using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using LibraryManagementSystem.Services.Interfaces;

namespace LibraryManagementSystem.Services.Implementations
{
    public class CategoryService : ICategoryService
    {
        private readonly ICategoryRepository _categoryRepository;
        private readonly IBookRepository _bookRepository;
        private readonly ILogger<CategoryService> _logger;

        public CategoryService(ICategoryRepository categoryRepository, IBookRepository bookRepository, ILogger<CategoryService> logger)
        {
            _categoryRepository = categoryRepository;
            _bookRepository = bookRepository;
            _logger = logger;
        }

        public async Task<IEnumerable<Category>> GetAllCategoriesAsync()
        {
            return await _categoryRepository.GetAllAsync();
        }

        public async Task<Category?> GetCategoryByIdAsync(int id)
        {
            return await _categoryRepository.GetByIdAsync(id);
        }

        public async Task<Category?> GetCategoryWithBooksAsync(int id)
        {
            return await _categoryRepository.GetCategoryWithBooksAsync(id);
        }

        public async Task CreateCategoryAsync(Category category)
        {
            await _categoryRepository.AddAsync(category);
            await _categoryRepository.SaveChangesAsync();
            _logger.LogInformation("Category created: {Name}", category.Name);
        }

        public async Task UpdateCategoryAsync(Category category)
        {
            _categoryRepository.Update(category);
            await _categoryRepository.SaveChangesAsync();
            _logger.LogInformation("Category updated: {Name}", category.Name);
        }

        public async Task DeleteCategoryAsync(int id)
        {
            var category = await _categoryRepository.GetByIdAsync(id);
            if (category != null)
            {
                _categoryRepository.Delete(category);
                await _categoryRepository.SaveChangesAsync();
                _logger.LogInformation("Category deleted: {Name} (Id: {Id})", category.Name, id);
            }
        }

        public async Task<bool> HasBooksAsync(int categoryId)
        {
            return await _bookRepository.ExistsAsync(b => b.CategoryId == categoryId);
        }
    }
}
