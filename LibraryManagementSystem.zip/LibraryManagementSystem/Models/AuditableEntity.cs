namespace LibraryManagementSystem.Models
{
    /// <summary>
    /// Extends BaseEntity with audit timestamps (Inheritance)
    /// </summary>
    public abstract class AuditableEntity : BaseEntity
    {
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? UpdatedAt { get; set; }
    }
}
