using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Repositories.Implementations
{
    public class IssuanceRepository : Repository<BookIssuance>, IIssuanceRepository
    {
        public IssuanceRepository(ApplicationDbContext context) : base(context) { }

        public async Task<BookIssuance?> GetIssuanceWithDetailsAsync(int id)
        {
            return await _dbSet
                .Include(i => i.Book)
                .Include(i => i.Member)
                .Include(i => i.IssuedByUser)
                .FirstOrDefaultAsync(i => i.Id == id);
        }

        public IQueryable<BookIssuance> GetIssuancesWithDetails()
        {
            return _dbSet
                .Include(i => i.Book)
                .Include(i => i.Member)
                .Include(i => i.IssuedByUser)
                .AsQueryable();
        }

        public async Task<IEnumerable<BookIssuance>> GetActiveIssuancesByMemberAsync(int memberId)
        {
            return await _dbSet
                .Include(i => i.Book)
                .Where(i => i.MemberId == memberId && i.Status == "Issued")
                .ToListAsync();
        }

        public async Task<IEnumerable<BookIssuance>> GetOverdueIssuancesAsync()
        {
            var today = DateTime.UtcNow.Date;
            return await _dbSet
                .Include(i => i.Book)
                .Include(i => i.Member)
                .Where(i => i.Status == "Issued" && i.DueDate.Date < today)
                .ToListAsync();
        }
    }
}
