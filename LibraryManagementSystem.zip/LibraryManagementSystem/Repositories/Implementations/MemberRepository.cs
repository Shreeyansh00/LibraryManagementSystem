using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Repositories.Implementations
{
    public class MemberRepository : Repository<Member>, IMemberRepository
    {
        public MemberRepository(ApplicationDbContext context) : base(context) { }

        public async Task<Member?> GetMemberWithIssuancesAsync(int id)
        {
            return await _dbSet
                .Include(m => m.Issuances)
                    .ThenInclude(i => i.Book)
                .FirstOrDefaultAsync(m => m.Id == id);
        }

        public async Task<Member?> GetByMembershipIdAsync(string membershipId)
        {
            return await _dbSet.FirstOrDefaultAsync(m => m.MembershipId == membershipId);
        }
    }
}
