using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LibraryManagementSystem.ViewModels
{
    /// <summary>
    /// ViewModel for issuing a book
    /// </summary>
    public class IssuanceViewModel
    {
        [Required(ErrorMessage = "Please select a book")]
        [Display(Name = "Book")]
        public int BookId { get; set; }

        [Required(ErrorMessage = "Please select a member")]
        [Display(Name = "Member")]
        public int MemberId { get; set; }

        [Display(Name = "Issue Date")]
        [DataType(DataType.Date)]
        public DateTime IssueDate { get; set; } = DateTime.UtcNow;

        [Display(Name = "Due Date")]
        [DataType(DataType.Date)]
        public DateTime DueDate { get; set; } = DateTime.UtcNow.AddDays(14);

        [StringLength(500)]
        public string? Remarks { get; set; }

        // Dropdown lists
        public List<SelectListItem> Books { get; set; } = new();
        public List<SelectListItem> Members { get; set; } = new();
    }
}
