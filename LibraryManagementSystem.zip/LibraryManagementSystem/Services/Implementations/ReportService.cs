using LibraryManagementSystem.Models;
using LibraryManagementSystem.Repositories.Interfaces;
using LibraryManagementSystem.Services.Interfaces;
using LibraryManagementSystem.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Services.Implementations
{
    /// <summary>
    /// Generates reports and dashboard statistics
    /// </summary>
    public class ReportService : IReportService
    {
        private readonly IIssuanceRepository _issuanceRepository;
        private readonly IBookRepository _bookRepository;
        private readonly IAuthorRepository _authorRepository;
        private readonly ICategoryRepository _categoryRepository;
        private readonly IMemberRepository _memberRepository;

        public ReportService(
            IIssuanceRepository issuanceRepository,
            IBookRepository bookRepository,
            IAuthorRepository authorRepository,
            ICategoryRepository categoryRepository,
            IMemberRepository memberRepository)
        {
            _issuanceRepository = issuanceRepository;
            _bookRepository = bookRepository;
            _authorRepository = authorRepository;
            _categoryRepository = categoryRepository;
            _memberRepository = memberRepository;
        }

        public async Task<PaginatedList<BookIssuance>> GetIssuedBooksReportAsync(
            DateTime? fromDate, DateTime? toDate, int pageIndex, int pageSize = 15)
        {
            var query = _issuanceRepository.GetIssuancesWithDetails();

            if (fromDate.HasValue)
                query = query.Where(i => i.IssueDate.Date >= fromDate.Value.Date);
            if (toDate.HasValue)
                query = query.Where(i => i.IssueDate.Date <= toDate.Value.Date);

            query = query.OrderByDescending(i => i.IssueDate);
            return await PaginatedList<BookIssuance>.CreateAsync(query, pageIndex, pageSize);
        }

        public async Task<PaginatedList<BookIssuance>> GetReturnedBooksReportAsync(
            DateTime? fromDate, DateTime? toDate, int pageIndex, int pageSize = 15)
        {
            var query = _issuanceRepository.GetIssuancesWithDetails()
                .Where(i => i.Status == "Returned");

            if (fromDate.HasValue)
                query = query.Where(i => i.ReturnDate!.Value.Date >= fromDate.Value.Date);
            if (toDate.HasValue)
                query = query.Where(i => i.ReturnDate!.Value.Date <= toDate.Value.Date);

            query = query.OrderByDescending(i => i.ReturnDate);
            return await PaginatedList<BookIssuance>.CreateAsync(query, pageIndex, pageSize);
        }

        public async Task<PaginatedList<BookIssuance>> GetOverdueBooksReportAsync(
            int pageIndex, int pageSize = 15)
        {
            var today = DateTime.UtcNow.Date;
            var query = _issuanceRepository.GetIssuancesWithDetails()
                .Where(i => i.Status == "Issued" && i.DueDate.Date < today)
                .OrderBy(i => i.DueDate);

            return await PaginatedList<BookIssuance>.CreateAsync(query, pageIndex, pageSize);
        }

        public async Task<DashboardViewModel> GetDashboardDataAsync()
        {
            var today = DateTime.UtcNow.Date;

            var dashboard = new DashboardViewModel
            {
                TotalBooks = await _bookRepository.CountAsync(),
                TotalMembers = await _memberRepository.CountAsync(),
                TotalAuthors = await _authorRepository.CountAsync(),
                TotalCategories = await _categoryRepository.CountAsync(),
                ActiveIssuances = await _issuanceRepository.CountAsync(i => i.Status == "Issued"),
                OverdueBooks = await _issuanceRepository.CountAsync(i => i.Status == "Issued" && i.DueDate.Date < today),
                BooksAvailable = await _bookRepository.CountAsync(b => b.AvailableCopies > 0),
                TotalReturned = await _issuanceRepository.CountAsync(i => i.Status == "Returned"),
            };

            // Recent issuances (last 5)
            dashboard.RecentIssuances = await _issuanceRepository.GetIssuancesWithDetails()
                .OrderByDescending(i => i.IssueDate)
                .Take(5)
                .ToListAsync();

            // Books by category
            dashboard.BooksByCategory = await _bookRepository.Query()
                .Include(b => b.Category)
                .GroupBy(b => b.Category!.Name)
                .Select(g => new CategoryBookCount
                {
                    CategoryName = g.Key,
                    Count = g.Count()
                })
                .ToListAsync();

            return dashboard;
        }
    }
}
