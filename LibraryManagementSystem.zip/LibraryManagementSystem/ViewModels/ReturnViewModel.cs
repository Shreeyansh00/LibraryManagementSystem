using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.ViewModels
{
    /// <summary>
    /// ViewModel for returning a book
    /// </summary>
    public class ReturnViewModel
    {
        public int IssuanceId { get; set; }
        public string BookTitle { get; set; } = string.Empty;
        public string MemberName { get; set; } = string.Empty;
        public DateTime IssueDate { get; set; }
        public DateTime DueDate { get; set; }

        [Display(Name = "Return Date")]
        [DataType(DataType.Date)]
        public DateTime ReturnDate { get; set; } = DateTime.UtcNow;

        public int OverdueDays { get; set; }
        public decimal FineAmount { get; set; }

        [StringLength(500)]
        public string? Remarks { get; set; }
    }
}
