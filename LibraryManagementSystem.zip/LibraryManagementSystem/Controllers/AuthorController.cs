using LibraryManagementSystem.Models;
using LibraryManagementSystem.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementSystem.Controllers
{
    /// <summary>
    /// Author CRUD controller
    /// </summary>
    [Authorize]
    public class AuthorController : Controller
    {
        private readonly IAuthorService _authorService;
        private readonly ILogger<AuthorController> _logger;

        public AuthorController(IAuthorService authorService, ILogger<AuthorController> logger)
        {
            _authorService = authorService;
            _logger = logger;
        }

        // GET: Author
        public async Task<IActionResult> Index()
        {
            var authors = await _authorService.GetAllAuthorsAsync();
            return View(authors);
        }

        // GET: Author/Create
        [Authorize(Roles = "Admin,Librarian")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Author/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Create(Author author)
        {
            if (!ModelState.IsValid)
                return View(author);

            await _authorService.CreateAuthorAsync(author);
            TempData["SuccessMessage"] = "Author created successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Author/Edit/5
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Edit(int id)
        {
            var author = await _authorService.GetAuthorByIdAsync(id);
            if (author == null)
                return NotFound();

            return View(author);
        }

        // POST: Author/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin,Librarian")]
        public async Task<IActionResult> Edit(int id, Author author)
        {
            if (id != author.Id)
                return NotFound();

            if (!ModelState.IsValid)
                return View(author);

            await _authorService.UpdateAuthorAsync(author);
            TempData["SuccessMessage"] = "Author updated successfully!";
            return RedirectToAction(nameof(Index));
        }

        // GET: Author/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int id)
        {
            var author = await _authorService.GetAuthorWithBooksAsync(id);
            if (author == null)
                return NotFound();

            if (await _authorService.HasBooksAsync(id))
            {
                TempData["ErrorMessage"] = "Cannot delete this author. They have associated books.";
                return RedirectToAction(nameof(Index));
            }

            return View(author);
        }

        // POST: Author/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (await _authorService.HasBooksAsync(id))
            {
                TempData["ErrorMessage"] = "Cannot delete this author. They have associated books.";
                return RedirectToAction(nameof(Index));
            }

            await _authorService.DeleteAuthorAsync(id);
            TempData["SuccessMessage"] = "Author deleted successfully!";
            return RedirectToAction(nameof(Index));
        }
    }
}
