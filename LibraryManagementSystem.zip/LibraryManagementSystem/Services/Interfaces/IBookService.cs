using LibraryManagementSystem.Models;
using LibraryManagementSystem.ViewModels;

namespace LibraryManagementSystem.Services.Interfaces
{
    public interface IBookService
    {
        Task<PaginatedList<Book>> GetBooksAsync(string? searchTerm, int? categoryId, string? availability, string? sortBy, string? sortOrder, int pageIndex, int pageSize = 10);
        Task<Book?> GetBookByIdAsync(int id);
        Task<Book?> GetBookWithDetailsAsync(int id);
        Task CreateBookAsync(Book book);
        Task UpdateBookAsync(Book book);
        Task DeleteBookAsync(int id);
        Task<bool> IsbnExistsAsync(string isbn, int? excludeId = null);
    }
}
