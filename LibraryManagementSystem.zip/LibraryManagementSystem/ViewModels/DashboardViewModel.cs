using LibraryManagementSystem.Models;

namespace LibraryManagementSystem.ViewModels
{
    public class DashboardViewModel
    {
        public int TotalBooks { get; set; }
        public int TotalMembers { get; set; }
        public int TotalAuthors { get; set; }
        public int TotalCategories { get; set; }
        public int ActiveIssuances { get; set; }
        public int OverdueBooks { get; set; }
        public int BooksAvailable { get; set; }
        public int TotalReturned { get; set; }
        public List<BookIssuance> RecentIssuances { get; set; } = new();
        public List<CategoryBookCount> BooksByCategory { get; set; } = new();
    }

    public class CategoryBookCount
    {
        public string CategoryName { get; set; } = string.Empty;
        public int Count { get; set; }
    }
}
